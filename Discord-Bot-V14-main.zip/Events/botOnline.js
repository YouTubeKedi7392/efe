require('../index')

const Discord = require('discord.js')
const client = require('../index')

client.on('ready', () => {
    console.log(`🔥 Bot Açık ${client.user.username}!`)


})
  


